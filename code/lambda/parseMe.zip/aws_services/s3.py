from datetime import datetime
import json
import logging
from pathlib import Path
from urllib.parse import urlencode, urlparse

import boto3
import botocore


def get_matching_s3_keys(bucket, prefix=None):
    """
    Create a list of keys in an S3 bucket with prefix.
    :param bucket: string: the S3 bucket name
    :param prefix: string: S3 prefix
    """
    s3 = boto3.client('s3')
    kwargs = {
        'Bucket': bucket,
    }

    # If the prefix is a single string (not a tuple of strings), we can
    # do the filtering directly in the S3 API.
    if isinstance(prefix, str):
        kwargs['Prefix'] = prefix

    key_list = []
    while True:
        # The S3 API response is a large blob of metadata.
        # 'Contents' contains information about the listed objects.
        resp = s3.list_objects_v2(**kwargs)

        try:
            contents = resp['Contents']
        except KeyError:
            return

        for obj in contents:
            key = obj['Key']
            if key.startswith(prefix) and key != prefix:
                key_list.append(key)

        # The S3 API is paginated, returning up to 1000 keys at a time.
        # Pass the continuation token into the next response, until we
        # reach the final page (when this field is missing).
        try:
            kwargs['ContinuationToken'] = resp['NextContinuationToken']
        except KeyError:
            break

    return key_list


def get_s3_object_to_local_file(s3_uri, output_dir):
    print(f'Fetching file {s3_uri} from S3.')
    s3 = boto3.resource('s3')
    bucket, file_key = parse_s3_uri(s3_uri)

    # The file key should have the structure raw/ASSET/file_name
    local_file_name = file_key.split('/')[-1]
    local_file_path = Path(output_dir) / local_file_name

    try:
        s3.Bucket(bucket).download_file(file_key, local_file_path.as_posix())
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            logging.exception("The object does not exist.")
            raise
        else:
            raise

    return local_file_path


def get_s3_uri(bucket, key):
    """
    Combines bucket and key into full S3 uri.

    :param bucket: str: bucket name
    :param key: str: key
    :return: str: combining bucket and key
    """
    return 's3://{}/{}'.format(bucket, key)


def parse_s3_uri(uri):
    """
    Parses full S3 uri into separate bucket and key.

    :param uri: Path
    :return: [str] with bucket and key
    """
    parse_result = urlparse(uri)
    bucket = parse_result.netloc
    file_key = parse_result.path.lstrip('/')
    return bucket, file_key


class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj_to_encode):
        if isinstance(obj_to_encode, datetime):
            return obj_to_encode.timestamp()

        return json.JSONEncoder.default(self, obj_to_encode)


def json_to_s3(s3_uri, json_data, tag_dict=None):
    """
    Uploads a json file to S3.

    :param s3_uri: S3 uri like s3://bucket/file/key
    :param json_data: json data
    :param tag_dict: tags to be added to file if needed
    :return: response from put action
    """
    logging.info('Uploading json to S3 file key %s .', s3_uri)
    s3 = boto3.resource('s3')

    if tag_dict is not None:
        tag_url = urlencode(tag_dict)
    else:
        tag_url = ''
    bucket, file_key = parse_s3_uri(s3_uri)
    try:
        response = s3.Object(bucket, file_key).put(
            Body=json.dumps(json_data, ensure_ascii=False, cls=CustomJSONEncoder),
            Tagging=tag_url, ContentType='text/json')
    except botocore.exceptions.ClientError as e:
        logging.exception('Error uploading JSON to S3.')
        raise
    return response