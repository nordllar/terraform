"""
Wrapper function to enable async calls to Lambda functions
"""

import asyncio
from aiohttp import ClientSession
import base64
from urllib.parse import urlparse

from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.session import Session


creds = Session().get_credentials()
LAMBDA_ENDPOINT_BASE = 'https://lambda.{region}.amazonaws.com/2015-03-31/functions'


def create_signed_headers(url, payload):
    host_segments = urlparse(url).netloc.split('.')
    service = host_segments[0]
    region = host_segments[1]
    request = AWSRequest(method='POST',
                         url=url,
                         data=payload)
    SigV4Auth(creds, service, region).add_auth(request)
    return dict(request.headers.items())


async def invoke(url, payload, session):
    signed_headers = create_signed_headers(url, payload)
    async with session.post(url,
                            data=payload,
                            headers=signed_headers) as response:
        return await response.json()


def generate_invocations(functions_and_payloads, base_url, session):
    for func_name, payload in functions_and_payloads:
        serialized_payload = '{'
        serialized_payload += f'"image_bytes": "{base64.b64encode(payload["image_bytes"]).decode("utf-8")}"'
        serialized_payload += '}'
        url = f'{base_url}/{func_name}/invocations'
        yield invoke(url, serialized_payload, session)


def invoke_all(functions_and_payloads, region='eu-west-1'):
    base_url = LAMBDA_ENDPOINT_BASE.format(region=region)

    async def wrapped():
        async with ClientSession(raise_for_status=False) as session:
                invocations = generate_invocations(functions_and_payloads,
                                                   base_url,
                                                   session)
                return await asyncio.gather(*invocations)

    return asyncio.get_event_loop().run_until_complete(wrapped())


def main():
    """
    Test function if needed.
    :return:
    """
    pass


if __name__ == '__main__':
    main()
