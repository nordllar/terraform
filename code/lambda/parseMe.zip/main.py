import json
import os
import platform
from urllib.parse import unquote_plus

from aws_services.s3 import get_s3_object_to_local_file, get_s3_uri
from parse_document.document import Document


def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))

    # If the event is coming from S3
    if event['Records'][0]['eventSource'] == 'aws:s3':
        bucket = event['Records'][0]['s3']['bucket']['name']
        object_key = event['Records'][0]['s3']['object']['key']

    # If the event is coming from SQS
    elif event['Records'][0]['eventSource'] == 'aws:sqs':
        s3_event_str = event['Records'][0]['body']
        s3_event = json.loads(s3_event_str)
        bucket = s3_event['Records'][0]['s3']['bucket']['name']
        object_key = s3_event['Records'][0]['s3']['object']['key']

    else:
        raise ValueError('Unknown event source.')

    # In the S3 event, space is replaced by '+', so change it back for the boto3 calls
    object_key = unquote_plus(object_key)
    main(bucket, object_key)
    return


def main(bucket, file_key):
    # Get the file from S3
    s3_uri = get_s3_uri(bucket, file_key)

    # Get the extension of the file, and only process files with supported file extensions
    file_extension = file_key.split('.')[-1]
    if file_extension not in ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'jpeg', 'jpg', 'png']:
        return

    if platform.system() == 'Windows':
        output_dir = 'tmp/'
    else:
        output_dir = '/tmp/'

    try:
        asset = file_key.split('/')[1]
    except:
        asset = None

    local_file_key = get_s3_object_to_local_file(s3_uri, output_dir)

    # Parse the file
    try:
        print(f"Parsing file {file_key}")
        parsed_document = Document(local_file_key, asset)

        # Upload the parsed file to S3
        parsed_document.document_to_s3(bucket, 'preprocessed_2')
    finally:
        os.remove(local_file_key)


if __name__ == '__main__':
    """
    Used for local testing.
    """
    with open('event.json') as file:
        event = json.load(file)

    lambda_handler(event, '')
