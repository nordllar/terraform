import json
import time
from urllib.parse import quote_plus

import boto3

from aws_services.s3 import get_matching_s3_keys


def main():
    # Fetch a list of processed files from S3
    bucket = 'fortum-hydro-dam-safety-documents-dev'
    file_keys = get_matching_s3_keys(bucket, 'raw/')

    client = boto3.client('sqs')
    sqs_uri = 'https://sqs.eu-west-1.amazonaws.com/924742621803/hydro-dam-safety-preprocessing'

    # Iterate over the files, and load them into Python objects one by one
    for i, file_key in enumerate(file_keys):

        encoded_file_key = quote_plus(file_key, safe='/')
        event = {
          "Records": [
            {
              "s3": {
                "bucket": {
                  "name": f"{bucket}"
                },
                "object": {
                  "key": f"{encoded_file_key}"
                }
              }
            }
          ]
        }
        message_body = json.dumps(event)
        response = client.send_message(
            QueueUrl=sqs_uri,
            MessageBody=message_body,
        )
        print(response['ResponseMetadata']['HTTPStatusCode'])
        if (i + 1) % 20 == 0:
            print(f'Completed {i / len(file_keys)} share of the work.')

    return


if __name__ == '__main__':
    main()
