from pathlib import Path

import PyPDF2
from PyPDF2.utils import PdfReadError

import parse_document.document
from parse_document.parse_doc import parse_doc_text
from parse_document.parse_pdf import parse_pdf, get_attachments
from parse_document.parse_ppt import parse_ppt_text
from parse_document.parse_image import parse_image_content


class DocumentContent:

    def __init__(self, file_path, file_extension, asset):
        self.doc_file_extension = file_extension
        self.file_path = file_path
        self.asset = asset
        self.text, self.images, self.attachments = self.extract_content()

    def extract_content(self):
        text = None
        images = []
        attachments = []

        if self.doc_file_extension in ['pdf']:

            # Check if the pdf file has attachments
            with open(self.file_path, 'rb') as handler:
                reader = PyPDF2.PdfFileReader(handler)
                try:
                    attachments_bytes = get_attachments(reader)
                except PdfReadError:
                    # If the PDF is encrypted, it will raise and PdfReadError. Ignore the attachments in that case
                    attachments_bytes = []

            # If there are attachments, parse them recursively
            if len(attachments_bytes) > 0:
                print(f'Found {len(attachments_bytes)} attachments in the PDF.')
                attachments = []
                for file_name, file_data in attachments_bytes.items():
                    print(f'Parsing attachment {file_name}.')
                    # Write the attachment to a temporary file
                    tmp_file_path = Path('/tmp') / file_name
                    with open(tmp_file_path, 'wb') as outfile:
                        outfile.write(file_data)
                    # Parse the attachment as a separate document from that file
                    attachments.append(parse_document.document.Document(tmp_file_path, self.asset))

            # Parse the text and images in raw format from the PDF root document
            text, images = parse_pdf(self.file_path)

        elif self.doc_file_extension in ['doc', 'docx']:
            # Word docs will only take care of the text content
            text = parse_doc_text(self.file_path)

        elif self.doc_file_extension in ['ppt', 'pptx']:
            # Word docs will only take care of the text content
            text = parse_ppt_text(self.file_path)

        elif self.doc_file_extension in ['jpg', 'jpeg', 'png']:
            # Create DocumentImage object.
            images = parse_image_content(self.file_path)

        else:
            pass

        return text, images, attachments

    def to_dict(self):
        """
        Serialize the class to a dict which can be serialized to JSON later on.
        :return:
        """
        record = {
            'text': self.text,
            'images': self.images,
            'attachments': [attachment.doc_os_metadata.file_name for attachment in self.attachments]
        }
        return record

    def attachments_to_s3(self, bucket, prefix):
        """
        Loops over the attachments and saves each of them to S3 under the attachment's file name
        :param bucket: S3 bucket name
        :param prefix: S3 file key prefix
        :return:
        """
        for attachment in self.attachments:
            attachment.document_to_s3(bucket, prefix)
