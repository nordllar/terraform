"""
Helper functions to parse PowerPoint files
"""

from tika import parser

from aws_services.lambda_async_invocation import invoke_all


def parse_image_metadata(file_path):
    parsed = parser.from_file(file_path.as_posix())
    metadata = parsed['metadata']

    return metadata


def parse_image_content(file_path):
    """
    Simply open the file and return a byte array
    :param file_path:
    :return:
    """
    with open(file_path, 'rb') as image:
        f = image.read()
        b = bytearray(f)

    func_name = 'ParseImage'
    funcs_and_payloads = [(func_name, {'image_bytes': b})]

    lambda_responses = invoke_all(funcs_and_payloads)

    return lambda_responses


def main(file_path):
    parsed = parser.from_file(file_path)
    metadata = parsed['metadata']
    content = parsed['content']
    return


if __name__ == '__main__':
    main("C:\\Users\\lundhmar\\projects\\hydro-dam-safety\\data\\input\\SKAL_Foto_2004_PICT0235.JPG")
