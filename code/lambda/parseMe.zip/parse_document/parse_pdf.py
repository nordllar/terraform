import io

from pdf2image import convert_from_path
from tika import parser

from aws_services.lambda_async_invocation import invoke_all


def get_attachments(reader):
    """
    Retrieves the file attachments of the PDF as a dictionary of file names
    and the file data as a bytestring.
    :return: dictionary of filenames and bytestrings
    """
    attachments = {}
    catalog = reader.trailer["/Root"]
    try:
        file_names = catalog['/Names']['/EmbeddedFiles']['/Names']
    except KeyError:
        # If there are no attachments, it will raise a KeyError here
        return attachments
    for file_name in file_names:
        if isinstance(file_name, str):
            data_index = file_names.index(file_name) + 1
            file_dict = file_names[data_index].getObject()
            file_data = file_dict['/EF']['/F'].getData()
            attachments[file_name] = file_data

    return attachments


def parse_pdf_metadata(file_path):
    """
    Parses the metadata from a PDF file by help of Apache Tika
    :param file_path:
    :return:
    """
    parsed = parser.from_file(file_path.as_posix())
    metadata = parsed['metadata']
    return metadata


def parse_pdf_text(file_path):
    """
    Parses the content from a PDF file by help of Apache Tika
    :param file_path:
    :return:
    """
    parsed = parser.from_file(file_path.as_posix())
    text = parsed['content']

    return text


def parse_pdf(file_path):
    """
    Top-level wrapper for reading a PDF file's content.
    :param file_path:
    :return:
    """
    # Parse the text from the PDF file
    text = parse_pdf_text(file_path)

    # For the root document, save each page of the PDF as an image
    try:
        pages = convert_from_path(file_path.as_posix(), fmt='jpeg', dpi=100)
        # Loop over the images and saves their bytes
        number_of_pages = len(pages)
        print(f'Found {number_of_pages} images from {file_path}.')

        if number_of_pages == 1:
            extract_text = 'True'
        else:
            extract_text = 'False'

        func_name = 'ParseImage'
        funcs_and_payloads = []
        for page in pages:
            f = io.BytesIO()
            page.save(f, format='jpeg')
            funcs_and_payloads.append((func_name,
                                       {'image_bytes': f.getvalue(),
                                        'classify_image': 'True',
                                        'extract_text': extract_text}))

        lambda_responses = invoke_all(funcs_and_payloads)

    except:
        print('Getting images from PDF with Poppler failed.')
        lambda_responses = []

    return text, lambda_responses
