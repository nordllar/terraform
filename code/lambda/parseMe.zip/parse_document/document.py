"""
Defines the wrapper classes for a document and its content.
"""

from aws_services.s3 import get_s3_uri, json_to_s3
import parse_document.document_content
from parse_document.parse_file_name_metadata import FileNameClassification, ContentTextClassification
from parse_document.parse_os_metadata import DocumentOSMetadata
from parse_document.parse_doc import parse_doc_metadata
from parse_document.parse_pdf import parse_pdf_metadata
from parse_document.parse_ppt import parse_ppt_metadata
from parse_document.parse_image import parse_image_metadata


class Document:

    def __init__(self, file_path, asset):
        self.asset = asset
        self.file_path = file_path
        # Parse OS metadata from the file
        self.doc_os_metadata = DocumentOSMetadata(file_path)
        self.doc_file_extension = self.doc_os_metadata.file_extension.lower()
        # Classify the file name
        self.file_name_classification = FileNameClassification(file_name=self.doc_os_metadata.file_name)
        # Parse file type specific metadata from the file
        self.file_specific_metadata = self.extract_file_specific_metadata()
        # Extract content from the document
        self.doc_content = parse_document.document_content.DocumentContent(file_path, self.doc_file_extension, asset)
        # If there is no file name classification, try to run it on the the text content
        self.content_text_classification = ContentTextClassification(document_text=self.doc_content.text)

    def extract_file_specific_metadata(self):
        if self.doc_file_extension in ['pdf']:
            file_specific_metadata = parse_pdf_metadata(self.file_path)
        elif self.doc_file_extension in ['doc', 'docx']:
            file_specific_metadata = parse_doc_metadata(self.file_path)
        elif self.doc_file_extension in ['ppt', 'pptx']:
            file_specific_metadata = parse_ppt_metadata(self.file_path)
        elif self.doc_file_extension in ['jpg', 'jpeg', 'png']:
            file_specific_metadata = parse_image_metadata(self.file_path)
        else:
            file_specific_metadata = None
        return file_specific_metadata

    def to_dict(self):
        """
        Serialize the class to a dict which can be serialized to JSON later on.
        :return:
        """
        record = {
            'asset': self.asset,
            'file_name_classification': self.file_name_classification.to_dict(),
            'content_text_classification': self.content_text_classification.to_dict(),
            'doc_os_metadata': self.doc_os_metadata.to_dict(),
            'doc_file_extension': self.doc_file_extension,
            'file_specific_metadata': self.file_specific_metadata,
            'doc_content': self.doc_content.to_dict(),
        }
        return record

    def document_to_s3(self, bucket, prefix):
        output_file_key = f'{prefix}/{self.doc_os_metadata.file_name}.json'
        output_s3_uri = get_s3_uri(bucket, output_file_key)
        json_to_s3(output_s3_uri, self.to_dict())
        self.doc_content.attachments_to_s3(bucket, prefix)
