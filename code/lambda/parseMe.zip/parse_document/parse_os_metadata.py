from datetime import datetime
import os
import platform


class DocumentOSMetadata:
    def __init__(self, file_path):
        self.file_path = file_path.as_posix()
        # This will return the file name including the extension
        file_name_raw = file_path.name.split('\\')[-1]
        # Remove the extension and only get the file name
        self.file_name = ''.join(file_name_raw.split('.')[:-1])
        # Save the file extension separately
        self.file_extension = file_name_raw.split('.')[-1]
        # Get the OS's file creation date
        self.file_creation_date = find_creation_date(file_path)
        # Get the OS's owner of the file
        self.file_owner, _ = find_file_owner(file_path.as_posix())

    def to_dict(self):
        record = {
            'file_name': self.file_name,
            'file_extension': self.file_extension,
            'file_creation_date': self.file_creation_date,
            'file_owner': self.file_owner,
        }
        return record


def find_file_owner(file_path):
    """
    Try to get the owner of a file if it was created by a Windows file system.
    http://timgolden.me.uk/python/win32_how_do_i/get-the-owner-of-a-file.html
    :param file_path:
    :return:
    """
    if platform.system() == 'Windows':
        """
        sd = win32security.GetFileSecurity(file_path, win32security.OWNER_SECURITY_INFORMATION)
        owner_sid = sd.GetSecurityDescriptorOwner()
        name, domain, type = win32security.LookupAccountSid(None, owner_sid)
        return name, domain
        """
        return None, None
    else:
        return None, None


def find_creation_date(file_path):
    """
    Try to get the date that a file was created, falling back to when it was
    last modified if that isn't possible.
    See http://stackoverflow.com/a/39501288/1709587 for explanation.
    https://stackoverflow.com/questions/237079/how-to-get-file-creation-modification-date-times-in-python
    """
    if platform.system() == 'Windows':
        return datetime.fromtimestamp(os.path.getctime(file_path))
    else:
        stat = os.stat(file_path)
        try:
            return datetime.fromtimestamp(stat.st_birthtime)
        except AttributeError:
            # We're probably on Linux. No easy way to get creation dates here,
            # so we'll settle for when its content was last modified.
            return datetime.fromtimestamp(stat.st_mtime)
