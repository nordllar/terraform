"""
Helper functions to parse PowerPoint files
"""

from tika import parser


def parse_ppt_text(file_path):
    parsed = parser.from_file(file_path.as_posix())
    text = parsed['content']

    return text


def parse_ppt_metadata(file_path):
    parsed = parser.from_file(file_path.as_posix())
    metadata = parsed['metadata']

    return metadata


def main(file_path):
    parsed = parser.from_file(file_path)
    metadata = parsed['metadata']
    content = parsed['content']
    return


if __name__ == '__main__':
    main("C:\\Users\\lundhmar\\projects\\hydro-dam-safety\\data/input\\SKAL_Dammsäkerhetsåtgärder.ppt")
