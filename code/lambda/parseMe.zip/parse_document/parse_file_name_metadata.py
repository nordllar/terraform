import re


class ContentTextClassification:
    def __init__(self, document_text):
        if document_text is not None:
            sub_cat_group_key_words = generate_key_words_dict('parse_document/backlund.txt')
            self.best_matching_category, self.best_matching_sub_category, self.max_count = \
                find_category(sub_cat_group_key_words, document_text)
            dpm_key_words = generate_key_words_dict('parse_document/dpm.txt', include_cat=False)
            self.dpm_category, self.dpm_sub_category, self.dpm_max_count = find_category(dpm_key_words, document_text)
        else:
            self.best_matching_category = None
            self.best_matching_sub_category = None
            self.max_count = None
            self.dpm_category = None
            self.dpm_sub_category = None
            self.dpm_max_count = None

    def to_dict(self):
        record = {
            'best_matching_category': self.best_matching_category,
            'best_matching_sub_category': self.best_matching_sub_category,
            'max_count': self.max_count,
            'dpm_category': self.dpm_category,
            'dpm_sub_category': self.dpm_sub_category,
            'dpm_max_count': self.dpm_max_count,
        }
        return record


class FileNameClassification:
    def __init__(self, file_name, asset=None):
        if asset is None:
            self.asset = parse_asset_name(file_name)
        else:
            self.asset = asset
        sub_cat_group_key_words = generate_key_words_dict('parse_document/backlund.txt')
        self.best_matching_category, self.best_matching_sub_category, self.max_count = \
            find_category(sub_cat_group_key_words, file_name)
        dpm_key_words = generate_key_words_dict('parse_document/dpm.txt', include_cat=False)
        self.dpm_category, self.dpm_sub_category, self.dpm_max_count = find_category(dpm_key_words, file_name)

    def to_dict(self):
        record = {
            'asset': self.asset,
            'best_matching_category': self.best_matching_category,
            'best_matching_sub_category': self.best_matching_sub_category,
            'max_count': self.max_count,
            'dpm_category': self.dpm_category,
            'dpm_sub_category': self.dpm_sub_category,
            'dpm_max_count': self.dpm_max_count,
        }
        return record


def parse_asset_name(file_name):
    try:
        file_name = file_name.replace(' ', '_')
        potential_asset_name = file_name.split('_')[0]
        # Matches 3-4 character long strings with A-Z capital letters only
        pattern = re.compile("^([A-Z]{3,4})")
        if pattern.match(potential_asset_name):
            return potential_asset_name
    except:
        return None


def file_name_preprocess(file, remove_first):
    string = file.replace(' ', '_')
    if remove_first:
        file_name_parts = string.split('_')[1:]
        file_name_parts = [file_name_part.lower() for file_name_part in file_name_parts
                           if len(file_name_part) > 2 and file_name_part.isalpha()]
    else:
        file_name_parts = None
    return file_name_parts


class AutoVivification(dict):
    def __missing__(self, key):
        value = self[key] = type(self)()
        return value


def generate_key_words_dict(file_name, include_cat=True):
    with open(file_name, 'r', encoding='UTF-8') as file:
        lines = file.readlines()
        lines = [line.strip('\n') for line in lines]

    # Loop over each line of the file
    sub_cat_group_key_words = AutoVivification()
    for line in lines:
        line_split = line.split(';')
        try:
            category = line_split[0].split(' ')[1].lower()
        except IndexError:
            category = line_split[0].lower()
        subcategory = line_split[1].lower()
        example = line_split[2].lower()

        # Split the file name into key words. The first work is the plant name, and the last is the date,
        # so ignore those. Only keep words of length >2, and also use the category and subcategory as well.
        key_words = []
        if include_cat is True:
            if category is not '':
                key_words.extend([category])
            if subcategory is not '':
                key_words.extend([subcategory])
            if example is not '':
                key_words.extend([word.lower().strip(' ') for word in example.split('_')[1:-1] if len(word) > 2])
        else:
            key_words.extend([word.lower().strip(' ') for word in example.split('_') if len(word) > 2])

        try:
            sub_cat_group_key_words[category][subcategory].extend(list(key_words))
        except (KeyError, AttributeError):
            sub_cat_group_key_words[category][subcategory] = list(key_words)

    # Get rid of duplicates by using a list -> set -> list transformation
    for key1, item1 in sub_cat_group_key_words.items():
        for key2, item2 in item1.items():
            sub_cat_group_key_words[key1][key2] = list(set(item2))

    return sub_cat_group_key_words


def find_category(category_dict, file_name):
    """
    Finds the best matching category
    :param category_dict:
    :param file_name:
    :return:
    """
    search_string = file_name.replace('_', ' ').lower()

    # Initialize the matches
    best_matching_category = 'unknown'
    best_matching_sub_category = 'unknown'
    max_count = 0

    # Loop over the main categories
    for key1, item1 in category_dict.items():

        # Loop over the sub-categories
        for key2, item2 in item1.items():

            # Extract the keywords. If the list is empty, continue to the next category
            key_words = item2
            if len(key_words) == 0:
                continue

            # Count the number of occurances of keywords in the file_name/string
            key_word_count = 0
            for key_word in key_words:
                key_word_count += len(re.findall(r'\b' + key_word + r'\b', search_string))

            if key_word_count > max_count:
                best_matching_category = key1
                best_matching_sub_category = key2
                max_count = key_word_count

    return best_matching_category, best_matching_sub_category, max_count


if __name__ == '__main__':
    asd = 'SKAL  elutrustning_utskovslucka_Besiktningsprotokoll'
    parse_asset_name(asd)
    # asd = FileNameClassification('SKAL_Damminmätning_slutlig_Rapport_version')
    sub_cat_key_words = generate_key_words_dict('backlund.txt')
    best_matching_category, best_matching_sub_category, best_jaccard_dist = \
        find_category(sub_cat_key_words, 'SKAL  elutrustning_utskovslucka_Besiktningsprotokoll')
    print('asd')

